using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;
using UnityEngine.InputSystem;

public class Ship : MonoBehaviour
{
    Vector2 Direction = Vector2.zero;
    [SerializeField] float Vitesse = 1f;
    [SerializeField] float FireRate = 5f;
    [SerializeField] GameObject Bullet;
    [SerializeField] Vector2 MuzzlePos = Vector2.zero;
    float Fired = 0;
    float BulletDelay = 1;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(Direction.normalized * Vitesse * Time.deltaTime);

        if (Fired > 0 && BulletDelay <= 0)
        {
            GameObject newBullet = Instantiate(Bullet, (Vector2)transform.position + MuzzlePos, Quaternion.identity);
            newBullet.AddComponent<Bullet>();
            BulletDelay = 1 / FireRate;
        }
        else
            BulletDelay -= Time.deltaTime;
    }

    public void Move(InputAction.CallbackContext context)
    {
        Direction = context.ReadValue<Vector2>();
    }
    public void Fire(InputAction.CallbackContext context)
    {
        Fired = context.ReadValue<float>();
    }
}
