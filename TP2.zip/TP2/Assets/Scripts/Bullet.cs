using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    [SerializeField] float TravelSpeed = 10f;
    [SerializeField] int MaxTravelTime = 2;
    DateTime CreationTime;
    
    // Start is called before the first frame update
    void Start()
    {
        CreationTime = DateTime.Now;
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector2.up * TravelSpeed * Time.deltaTime);
    }

    private void FixedUpdate()
    {
        DateTime currentTime = DateTime.Now;
        if (currentTime.Second - CreationTime.Second >= MaxTravelTime)
        {
            GameObject.Destroy(gameObject);
        }
    }
}
